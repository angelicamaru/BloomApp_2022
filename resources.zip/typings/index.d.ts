/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/sweetalert/index.d.ts" />
