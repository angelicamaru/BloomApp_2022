export const firebaseConfig= {
    apiKey: "AIzaSyB-CHGXqLBlKQfHmHHYVsIT-_AyBYNkFS0",
    authDomain: "bloomsabana.firebaseapp.com",
    databaseURL: "https://bloomsabana.firebaseio.com",
    projectId: "bloomsabana",
    storageBucket: "bloomsabana.appspot.com",
    messagingSenderId: "584579774141"
};
