import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PruebaPage } from './prueba';

@NgModule({
  declarations: [
    PruebaPage,
  ],
  imports: [
    IonicPageModule.forChild(PruebaPage),
  ],
})
export class PruebaPageModule {}
