import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_1Page } from './juego-1';

@NgModule({
  declarations: [
    Juego_1Page,
  ],
  imports: [
    IonicPageModule.forChild(Juego_1Page),
  ],
})
export class Juego_1PageModule {}
