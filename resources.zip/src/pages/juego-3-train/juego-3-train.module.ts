import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_3TrainPage } from './juego-3-train';

@NgModule({
  declarations: [
    Juego_3TrainPage,
  ],
  imports: [
    IonicPageModule.forChild(Juego_3TrainPage),
  ],
})
export class Juego_3TrainPageModule {}
