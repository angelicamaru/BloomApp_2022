import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_3Page } from './juego-3';

@NgModule({
  declarations: [
    Juego_3Page,
  ],
  imports: [
    IonicPageModule.forChild(Juego_3Page),
  ],
})
export class Juego_3PageModule {}
