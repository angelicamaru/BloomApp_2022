import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_4Page } from './juego-4';

@NgModule({
  declarations: [
    Juego_4Page,
  ],
  imports: [
    IonicPageModule.forChild(Juego_4Page),
  ],
})
export class Juego_4PageModule {}
