import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_5Page } from './juego-5';

@NgModule({
  declarations: [
    Juego_5Page,
  ],
  imports: [
    IonicPageModule.forChild(Juego_5Page),
  ],
})
export class Juego_5PageModule {}
