import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_5TrainPage } from './juego-5-train';

@NgModule({
  declarations: [
    Juego_5TrainPage,
  ],
  imports: [
    IonicPageModule.forChild(Juego_5TrainPage),
  ],
})
export class Juego_5TrainPageModule {}
