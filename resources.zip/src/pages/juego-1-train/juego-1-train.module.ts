import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_1TrainPage } from './juego-1-train';

@NgModule({
  declarations: [
    Juego_1TrainPage,
  ],
  imports: [
    IonicPageModule.forChild(Juego_1TrainPage),
  ],
})
export class Juego_1TrainPageModule {}
