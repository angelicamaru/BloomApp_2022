import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_2TrainPage } from './juego-2-train';

@NgModule({
  declarations: [
    Juego_2TrainPage,
  ],
  imports: [
    IonicPageModule.forChild(Juego_2TrainPage),
  ],
})
export class Juego_2TrainPageModule {}
