import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_4TrainPage } from './juego-4-train';

@NgModule({
  declarations: [
    Juego_4TrainPage,
  ],
  imports: [
    IonicPageModule.forChild(Juego_4TrainPage),
  ],
})
export class Juego_4TrainPageModule {}
