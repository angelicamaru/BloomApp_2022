import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Juego_2Page } from './juego-2';

@NgModule({
  declarations: [
    Juego_2Page,
  ],
  imports: [
    IonicPageModule.forChild(Juego_2Page),
  ],
})
export class Juego_2PageModule {}
